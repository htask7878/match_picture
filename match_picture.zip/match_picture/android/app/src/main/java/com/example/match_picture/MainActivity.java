package com.example.match_picture;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
